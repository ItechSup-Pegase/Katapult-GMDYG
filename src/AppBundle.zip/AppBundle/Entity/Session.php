<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * Session
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="AppBundle\Entity\SessionRepository")
 */
class Session
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date", type="date")
     */
    private $date;

    /**
     * Relation
     *
     *@ORM\ManyToOne(targetEntity="Formateur", inversedBy="sessions")
     *@ORM\JoinColumn(name="formateur_id", referencedColumnName="id")
     */
    protected $formateur;

    /**
     *@ORM\OneToMany(targetEntity="Stagiaire", mappedBy="session")
     */
    protected $stagiaires;

    /**    
     *@ORM\ManyToOne(targetEntity="Formation", inversedBy="sessions")
     *@ORM\JoinColumn(name="formation_id", referencedColumnName="id")
     *
     */    
    protected $formation;

    /*
     * Constructeur Relations
     *
     */
    public function __construct()
    {
        $this->stagiaires = new ArrayCollection();
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set date
     *
     * @param \DateTime $date
     * @return Session
     */
    public function setdate($date)
    {
        $this->date = $date;

        return $this;
    }

    /**
     * Get date
     *
     * @return \DateTime 
     */
    public function getdate()
    {
        return $this->date;
    }

    /**
     * Add stagiaires
     *
     * @param \AppBundle\Entity\Stagiaire $stagiaires
     * @return Session
     */
    public function addStagiaire(\AppBundle\Entity\Stagiaire $stagiaires)
    {
        $this->stagiaires[] = $stagiaires;

        return $this;
    }

    /**
     * Remove stagiaires
     *
     * @param \AppBundle\Entity\Stagiaire $stagiaires
     */
    public function removeStagiaire(\AppBundle\Entity\Stagiaire $stagiaires)
    {
        $this->stagiaires->removeElement($stagiaires);
    }

    /**
     * Get stagiaires
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getStagiaires()
    {
        return $this->stagiaires;
    }

    /**
     * Set formation
     *
     * @param \AppBundle\Entity\Formation $formation
     * @return Session
     */
    public function setFormation(\AppBundle\Entity\Formation $formation = null)
    {
        $this->formation = $formation;

        return $this;
    }

    /**
     * Get formation
     *
     * @return \AppBundle\Entity\Formation 
     */
    public function getFormation()
    {
        return $this->formation;
    }

    /**
     * Set formateur
     *
     * @param \AppBundle\Entity\Formateur $formateur
     * @return Session
     */
    public function setFormateur(\AppBundle\Entity\Formateur $formateur = null)
    {
        $this->formateur = $formateur;

        return $this;
    }

    /**
     * Get formateur
     *
     * @return \AppBundle\Entity\Formateur 
     */
    public function getFormateur()
    {
        return $this->formateur;
    }
}
